# UVMS DJ PRO

Professional browser DJ interface. Upload to GitHub Pages as `index.html`.

Online music playback must use an official provider/API that permits third-party web playback. This project does not bypass provider restrictions.
